﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace web_BACK_END
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "Iservice_application" in both code and config file together.
    [ServiceContract]
    public interface Iservice_application
    {
        [OperationContract]
        User Register(string name , string surname , string email , string contact , string type , string password);

        [OperationContract]
        User Login(string email, string password);

        [OperationContract]
        bool userExistence(string email);

        [OperationContract]
        List<Product> prod_List();

        [OperationContract]
        Product getProd(int id);

        [OperationContract]
        List<Product> getProdByType(string prodtype);

        [OperationContract]
        List<Product> getProdByColour(string prodColour);

        [OperationContract]
        List<Product> getProdByName(string prodname);

        [OperationContract]
        List<Product> getProdByPrice(decimal minPrice , decimal maxPrice);

        [OperationContract]
        List<Product> getProdByYear(int date);

        [OperationContract]
        WishList addToWishList(int ProdID, string prodImage, string prodname, double prodPrice , double prodDiscount);

        [OperationContract]
        ShoppingCart addToCart(int ProdID, int UserID, string prodname, double prodPrice , string prodImage , string prodType , int prodQuant , double totalPrice , double prodDiscount);

        [OperationContract]
        List<WishList> GetWishListItems();

        [OperationContract]
        List<ShoppingCart> getAddedItems(int userID);

        [OperationContract]
        bool increaseQuantity(int id);

        [OperationContract]
        bool decreaseQuantity(int id);

        [OperationContract]
        bool removeFromWishlist(int id);

        [OperationContract]
        bool removeFromCart(int id);

        [OperationContract]
        bool AddProduct(string prodname , string colour , double prodPrice , string prodImage , string prodType , double prodDiscount , DateTime prodDtae);

        [OperationContract]
        bool editProduct(int prodID , string prodname, string colour, double prodPrice, string prodImage, string prodType, double prodDiscount, DateTime prodDtae);

        [OperationContract]
        bool deleteProduct(int prodID);

        [OperationContract]
        double totalPRICE(int userID);

        [OperationContract]
        Invoice generateInvoice(double prodTotalprice, string username , string userSURNAME , string userContact , string userEmail , string userADDRESS , string userCity , DateTime date , double totalDiscount , int userid , double tax);

        [OperationContract]
        ProductReview addToProdReview(int userID , string userNAME , string userdesc , int prodID , double prodPRICE , string prodImage , string prodname , string proddesc);

        [OperationContract]
        List<ProductReview> prodReviewList(int id);

        [OperationContract]
        List<ProductReview> prodReviewListByPRODID(int id);

        [OperationContract]
        bool editProdReview(int uniqueID ,string proddesc);

    }
}
 