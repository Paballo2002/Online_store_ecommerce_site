﻿using HashPass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace web_BACK_END
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "service_application" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select service_application.svc or service_application.svc.cs at the Solution Explorer and start debugging.
    public class service_application : Iservice_application
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        public bool AddProduct(string prodname, string colour, double prodPrice, string prodImage, string prodType, double prodDiscount, DateTime prodDtae)
        {
            var prodExist = (from e in db.Products where (e.PROD_IMAGE.Equals(prodImage) && e.PROD_TYPE.Equals(prodType) && e.PROD_PRICE == (decimal)prodPrice) select e).FirstOrDefault();
            if (prodExist != null)
            {
                prodExist.PROD_NAME = prodname;
                prodExist.PROD_IMAGE = prodImage;
                prodExist.PROD_PRICE = (decimal)prodPrice;
                prodExist.PROD_TYPE = prodType;
                prodExist.PROD_COLOUR = colour;
                prodExist.PROD_CREATION_DATE = prodDtae;
                prodExist.PROD_DISCOUNT = (decimal)prodDiscount;
                db.SubmitChanges();

                return true;
            }
            else
            {
                var addToProduct = new Product
                {
                    PROD_NAME = prodname,
                    PROD_IMAGE = prodImage,
                    PROD_PRICE = (decimal)prodPrice,
                    PROD_TYPE = prodType,
                    PROD_COLOUR = colour,
                    PROD_CREATION_DATE = prodDtae,
                    PROD_DISCOUNT = (decimal)prodDiscount,
                };
                db.Products.InsertOnSubmit(addToProduct);
                try
                {
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return false;
                }
            }
        }

        public ShoppingCart addToCart(int ProdID, int UserID, string prodname, double prodPrice, string prodImage, string prodType, int prodQuant, double totalPrice, double prodDiscount)
        {
            var prodExist = (from e in db.ShoppingCarts where e.USER_ID == UserID && e.PROD_ID == ProdID select e).FirstOrDefault();
            if (prodExist != null)
            {
                prodExist.USER_ID = UserID;
                prodExist.PROD_ID = ProdID;
                prodExist.PROD_IMAGE = prodImage;
                prodExist.PROD_NAME = prodname;
                prodExist.PROD_PRICE = (decimal)prodPrice;
                prodExist.PROD_TYPE = prodType;
                prodExist.PROD_QUANTITY = prodQuant;
                prodExist.TOTAL_PRICE = (decimal)prodPrice - (decimal)prodDiscount;
                prodExist.DISCOUNT_PRICE = (decimal)prodDiscount;
                db.SubmitChanges();

                return prodExist;
            }
            else
            {
                var addToCart = new ShoppingCart
                {
                    USER_ID = UserID,
                    PROD_ID = ProdID,
                    PROD_IMAGE = prodImage,
                    PROD_NAME = prodname,
                    PROD_PRICE = (decimal)prodPrice,
                    PROD_TYPE = prodType,
                    PROD_QUANTITY = prodQuant,
                    TOTAL_PRICE = (decimal)prodPrice - (decimal)prodDiscount,
                    DISCOUNT_PRICE = (decimal)prodDiscount,
                };
                db.ShoppingCarts.InsertOnSubmit(addToCart);
                try
                {
                    db.SubmitChanges();
                    return addToCart;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return null;
                }
            }
        }

        public ProductReview addToProdReview(int userID, string userNAME, string userdesc, int prodID, double prodPRICE, string prodImage, string prodname, string proddesc)
        {
            var prodreview = new ProductReview
            {
                userID = userID,
                userNAME = userNAME,
                userDESCRIPTION = userdesc,
                productID = prodID,
                PRODpRICE = (decimal)prodPRICE,
                prodIMAGE = prodImage,
                prodNAME = prodname,
                prodDescrption = proddesc
            };
            db.ProductReviews.InsertOnSubmit(prodreview);
            try
            {
                db.SubmitChanges();
                return prodreview;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();
                return null;
            }
        }

        public WishList addToWishList(int ProdID, string prodImage, string prodname, double prodPrice, double prodDiscount)
        {
            var prodExist = (from e in db.WishLists where e.PROD_ID == ProdID select e).FirstOrDefault();
            if(prodExist != null)
            {
                prodExist.PROD_ID = ProdID;
                prodExist.PROD_IMAGE = prodImage;
                prodExist.PROD_NAME = prodname;
                prodExist.PROD_PRICE = (decimal)prodPrice;
                prodExist.PROD_DISCOUNT = (decimal)prodDiscount;
                db.SubmitChanges();

                return prodExist;
            }
            else
            {
                var addTowishlist = new WishList
                {
                    PROD_ID = ProdID,
                    PROD_IMAGE = prodImage,
                    PROD_NAME = prodname,
                    PROD_PRICE = (decimal)prodPrice,
                    PROD_DISCOUNT = (decimal)prodDiscount,
                };
                db.WishLists.InsertOnSubmit(addTowishlist);
                try
                {
                    db.SubmitChanges();
                    return addTowishlist;
                }
                catch (Exception ex)
                {
                    ex.GetBaseException();
                    return null;
                }
            }
        }

        public bool decreaseQuantity(int id)
        {
            var getProd = (from g in db.ShoppingCarts where (g.Id == id) select g).FirstOrDefault();
            if(getProd != null)
            {
                if(getProd.PROD_QUANTITY <= 1)
                {
                    getProd.PROD_QUANTITY = 1;
                    getProd.TOTAL_PRICE = (decimal)(getProd.PROD_PRICE - getProd.DISCOUNT_PRICE) * (getProd.PROD_QUANTITY);
                    db.SubmitChanges();
                    return false;
                }
                else
                {
                    int qunt = (getProd.PROD_QUANTITY--) - 1;
                    getProd.TOTAL_PRICE = (decimal)(getProd.PROD_PRICE - getProd.DISCOUNT_PRICE) * qunt;
                    db.SubmitChanges();
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        public bool deleteProduct(int prodID)
        {
            var getITEm = (from t in db.Products where t.Id == prodID select t).FirstOrDefault();
            if (getITEm != null)
            {
                db.Products.DeleteOnSubmit(getITEm);
                db.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool editProdReview(int uniqueID, string proddesc)
        {
            var getProdReview = (from e in db.ProductReviews where e.Id == uniqueID select e).FirstOrDefault();
            if(getProdReview != null)
            {
                getProdReview.prodDescrption = proddesc;
                db.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool editProduct(int prodID , string prodname, string colour, double prodPrice, string prodImage, string prodType, double prodDiscount, DateTime prodDtae)
        {
            var prodExist = (from e in db.Products where (e.Id == prodID) select e).FirstOrDefault();
            if (prodExist != null)
            {
                prodExist.PROD_NAME = prodname;
                prodExist.PROD_IMAGE = prodImage;
                prodExist.PROD_PRICE = (decimal)prodPrice;
                prodExist.PROD_TYPE = prodType;
                prodExist.PROD_COLOUR = colour;
                prodExist.PROD_CREATION_DATE = prodDtae;
                prodExist.PROD_DISCOUNT = (decimal)prodDiscount;

                db.SubmitChanges();
                return true;
            }

            else
            {
                return false;   
            }
        }

        public Invoice generateInvoice(double prodTotalprice, string username, string userSURNAME, string userContact, string userEmail, string userADDRESS, string userCity, DateTime date, double totalDiscount, int userid, double tax)
        {
            var addToInvoice = new Invoice
            {
                PROD_TOTAL = (decimal)prodTotalprice,
                USER_NAME = username,
                USER_LASTNAME = userSURNAME,
                USER_CONATCT = userContact,
                USER_EMAIL = userEmail,
                USER_ADRESS = userADDRESS,
                USER_city = userCity,
                DATE = date,
                TOTAL_DISC = (decimal)totalDiscount,
                USER_ID = userid,
                VAT = (decimal)tax
            };
            db.Invoices.InsertOnSubmit(addToInvoice);
            try
            {
                db.SubmitChanges();
                return addToInvoice;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();
                return null;
            }
        }

        public List<ShoppingCart> getAddedItems(int userID)
        {
            var getAddedItems = (from t in db.ShoppingCarts where t.USER_ID == userID select t).DefaultIfEmpty().ToList();
            if (getAddedItems != null)
            {
                return getAddedItems;
            }
            else
            {
                return null;
            }
        }

        public Product getProd(int id)
        {
            var getprod = (from p in db.Products where p.Id == id select p).FirstOrDefault();
            if (getprod != null)
            {
                return getprod;
            }
            else
            {
                return null;
            }
        }

        public List<Product> getProdByColour(string prodColour)
        {
            var getprodColour = (from t in db.Products where t.PROD_COLOUR.Equals(prodColour) select t).DefaultIfEmpty().ToList();
            if (getprodColour != null)
            {
                return getprodColour;
            }
            else
            {
                return null;
            }
        }

        public List<Product> getProdByName(string prodname)
        {
            var getprodName = (from t in db.Products where t.PROD_NAME.Equals(prodname) select t).DefaultIfEmpty().ToList();
            if (getprodName != null)
            {
                return getprodName;
            }
            else
            {
                return null;
            }
        }

        public List<Product> getProdByPrice(decimal minPrice, decimal maxPrice)
        {

            var getprodPrice = (from t in db.Products where (t.PROD_PRICE >  minPrice && t.PROD_PRICE <= maxPrice) select t).DefaultIfEmpty().ToList();
            if (getprodPrice != null)
            {
                return getprodPrice;
            }
            else
            {
                return null;
            }
        }

        public List<Product> getProdByType(string prodtype)
        {
            var getprodtype = (from t in db.Products where t.PROD_TYPE.Equals(prodtype) select t).DefaultIfEmpty().ToList();
            if(getprodtype != null)
            {
                return getprodtype;
            }
            else
            {
                return null;
            }
        }

        public List<Product> getProdByYear(int date)
        {
            var getproddate = (from t in db.Products where (t.PROD_CREATION_DATE.Year).Equals(date) select t).DefaultIfEmpty().ToList();
            if (getproddate != null)
            {
                return getproddate;
            }
            else
            {
                return null;
            }
        }

        public List<WishList> GetWishListItems()
        {
            var getWishListItems = (from t in db.WishLists select t).DefaultIfEmpty().ToList();
            if (getWishListItems != null)
            {
                return getWishListItems;
            }
            else
            {
                return null;
            }
        }

        public bool increaseQuantity(int id)
        {
            var getProd = (from g in db.ShoppingCarts where (g.Id == id) select g).FirstOrDefault();
            if (getProd != null)
            {
                if (getProd.PROD_QUANTITY >= 10)
                {
                    getProd.PROD_QUANTITY = 10;
                    getProd.TOTAL_PRICE = (decimal)(getProd.PROD_PRICE - getProd.DISCOUNT_PRICE) * getProd.PROD_QUANTITY;
                    db.SubmitChanges();
                    return false;
                }
                else
                {
                    int qunt = 1 + getProd.PROD_QUANTITY++;
                    getProd.TOTAL_PRICE = (decimal)(getProd.PROD_PRICE - getProd.DISCOUNT_PRICE) * (qunt);
                    db.SubmitChanges();
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        public User Login(string email, string password)
        {
            string hashedpass = Secrecy.HashPassword(password);
            var login = (from l in db.Users where l.USEREMAIL.Equals(email) && l.USERPASSWORD.Equals(hashedpass) select l).FirstOrDefault();
            if(login != null)
            {
                return login;
            }
            else
            {
                return null;
            }
        }

        public List<ProductReview> prodReviewList(int id)
        {
            var getReview = (from r in db.ProductReviews where r.userID == id select r).DefaultIfEmpty().ToList();
           if(getReview != null)
            {
                return getReview;
            }
            else
            {
                return null;
            }
        }

        public List<ProductReview> prodReviewListByPRODID(int id)
        {
            var getReview = (from r in db.ProductReviews where r.productID == id select r).DefaultIfEmpty().ToList();
            if (getReview != null)
            {
                return getReview;
            }
            else
            {
                return null;
            }
        }

        public List<Product> prod_List()
        {
            var getPRDS = (from p in db.Products select p).DefaultIfEmpty().ToList();

            if (getPRDS != null)
            {
                return getPRDS;
            }
            else
            {
                return null;
            }
        }

        public User Register(string name, string surname, string email, string contact, string type, string password)
        {
            var reg = new User
            {
                USERNAME = name,
                USERSURNAME = surname,
                USEREMAIL = email,
                USERCONTACT = contact,
                USERTYPE = type,
                USERPASSWORD = Secrecy.HashPassword(password)
            };
            db.Users.InsertOnSubmit(reg);
            try
            {
                db.SubmitChanges();
                return reg;
            }
            catch(Exception ex)
            {
                ex.GetBaseException();
                return null;
            }
        }

        public bool removeFromCart(int id)
        {
            var getITEm = (from t in db.ShoppingCarts where t.Id == id select t).FirstOrDefault();
            if (getITEm != null)
            {
                db.ShoppingCarts.DeleteOnSubmit(getITEm);
                db.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool removeFromWishlist(int id)
        {
            try
            {
                var getITEm = (from t in db.WishLists where t.PROD_ID == id select t).FirstOrDefault();
                if (getITEm != null)
                {
                    db.WishLists.DeleteOnSubmit(getITEm);
                    db.SubmitChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                ex.GetBaseException();
                return false;
            }
        }

        public double totalPRICE(int userID)
        {
            var checkUser = (from f in db.ShoppingCarts where f.USER_ID == userID select f).FirstOrDefault();
            if (checkUser != null)
            {
                var getTotalPRICE = (from g in db.ShoppingCarts where g.USER_ID == userID select g.TOTAL_PRICE).Sum();
                if (getTotalPRICE > 0)
                {
                    return (double)getTotalPRICE;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }

        public bool userExistence(string email)
        {
            var exist = (from e in db.Users where e.USEREMAIL.Equals(email) select e).FirstOrDefault();
            if(exist != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
