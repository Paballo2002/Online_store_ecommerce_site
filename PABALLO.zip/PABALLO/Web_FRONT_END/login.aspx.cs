﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class login : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            var login = sr.Login(useremail.Value,userpassword.Value);
            if(login != null)
            {
                Session["Customer"] = login.Id;
                Session["manager"] = login.Id;
                Session["customername"] = login.USERNAME;
                Session["TYPE"] = login.USERTYPE;
                Response.Redirect("category.aspx");
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Incorrect Credentials')", true);
            }
        }
    }
}