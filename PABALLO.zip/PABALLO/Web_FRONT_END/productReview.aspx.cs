﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class productReview : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                displayProducts();
            }
        }
        private void displayProducts()
        {
            int usrID = int.Parse(Session["Customer"].ToString());
            var getProducts = sr.prodReviewList(usrID);
            String display = "";
            if (getProducts != null)
            {
                foreach (ProductReview p in getProducts)
                {
                    if (p != null)
                    {
                        display += "<tr>";
                        display += "  <td>";
                        display += "    <div class=\"media\">";
                        display += "      <div class=\"d-flex\">";
                        display += "        <img src=" + p.prodIMAGE + " alt=\"\" width=\"100\" height=\"100\"/>";
                        display += "      </div>";
                        display += "    </div>";
                        display += "  </td>";
                        display += "  <td>";
                        display += "    <div class=\"media\">";
                        display += "      <div class=\"media-body\">";
                        display += "        <p>" + p.prodNAME + "</p>";
                        display += "      </div>";
                        display += "    </div>";
                        display += "  </td>";
                        display += "  <td>";
                        display += "    <h5>R" + p.PRODpRICE + "</h5>";
                        display += "  </td>";
                        display += "  <td>";
                        display += "    <div class=\"media\">";
                        display += "      <div class=\"media-body\">";
                        display += "        <p>" + p.prodDescrption + "</p>";
                        display += "      </div>";
                        display += "    </div>";
                        display += "  </td>";
                        display += "  <td>";
                        display += "    <div class=\"media\">";
                        display += "      <div class=\"media-body\">";
                        display += "        <a class=\"btn_1\" href='UpdateProductReview.aspx?updateIDreview=" + p.Id + "'>Update Review</a>";
                        display += "      </div>";
                        display += "    </div>";
                        display += "  </td>";
                        display += "</tr>";
                    }
                }
                tableDisplay.InnerHtml = display;
            }
        }
    }
}