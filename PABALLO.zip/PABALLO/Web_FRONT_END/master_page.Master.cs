﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web_FRONT_END
{
    public partial class master_page : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbllogin.Visible = true;
            lblreg.Visible = true;
            lblManCustReg.Visible = false;
            lblProductMan.Visible = false;
            lblReview.Visible = false;

            if (Session["Customer"] != null && Session["TYPE"].Equals("customer"))
            {
                lbllogin.Visible = false;
                lblreg.Visible = false;
                lblReview.Visible = true;
            }
            if(Session["manager"] != null && Session["TYPE"].Equals("Manager"))
            {
                lbllogin.Visible = false;
                lblreg.Visible = false;
                lblManCustReg.Visible = true;
                lblProductMan.Visible = true;
            }
        }
    }
}