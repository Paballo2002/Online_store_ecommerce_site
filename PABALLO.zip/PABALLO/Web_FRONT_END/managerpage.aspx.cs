﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class managerpage : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            displayProducts();
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if(Request.QueryString["deleteID"] != null)
            {
                int prodID = int.Parse(Request.QueryString["deleteID"]);
                var deleteProd = sr.deleteProduct(prodID);
                if(deleteProd)
                {
                    displayProducts();
                }
                else
                {
                    displayProducts();
                }
            }
        }

        private void displayProducts()
        {
            var getProducts = sr.prod_List();
            String display = "";
            if(getProducts != null)
            {
                foreach (Product p in getProducts)
                {

                    display += "<tr>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"d-flex\">";
                    display += "        <img src="+p.PROD_IMAGE+ " alt=\"\" width=\"100\" height=\"100\"/>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"media-body\">";
                    display += "        <p>"+p.PROD_NAME+"</p>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <h5>R"+p.PROD_PRICE+"</h5>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"media-body\">";
                    display += "        <p>R"+p.PROD_DISCOUNT+"</p>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"media-body\">";
                    display += "        <a class=\"btn_1\" href='UpdateProduct.aspx?updateID=" + p.Id+"'>Update Product</a>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"media-body\">";
                    display += "        <a class=\"btn_1\" href='?deleteID=" + p.Id + "'>Delete Product</a>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "</tr>";
                }
                display += "<tr class=\"bottom_button\">";
                display += "<td>"; 
                display += "<a class=\"btn_1\" href='AddProduct.aspx'>Add Products</a>";   
                display += "</td>"; 
                display += "</tr>"; 

                tableDisplay.InnerHtml = display;
            }
            
        }
    }
}