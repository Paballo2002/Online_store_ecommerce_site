﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class singleproduct : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Request.QueryString["prodid"] != null)
            {
                int prodid = int.Parse(Request.QueryString["prodid"]);
                generateSingleProduct(prodid);
            }
        }

        private void generateSingleProduct(int prodid)
        {
            string display = "";
            var getPROD = sr.getProd(prodid);

            var getReviewList = sr.prodReviewListByPRODID(prodid);

            if (getPROD != null)
            {
                display += "<div class=\"col-lg-7 col-xl-7\">";
                display += "<div class=\"product_slider_img\">";
                display += "<div id=\"vertical\">";
                display += "<div data-thumb=" + getPROD.PROD_IMAGE + ">";
                display += "<img src=" + getPROD.PROD_IMAGE + "/>";
                display += "</div>";
                display += "<div data-thumb=" + getPROD.PROD_IMAGE + ">";
                display += "<img src=" + getPROD.PROD_IMAGE + "/>";
                display += "</div>";
                display += "<div data-thumb=" + getPROD.PROD_IMAGE + ">";
                display += "<img src=" + getPROD.PROD_IMAGE + ">";
                display += "</div>";
                display += "<div data-thumb=" + getPROD.PROD_IMAGE + ">";
                display += "<img src=" + getPROD.PROD_IMAGE + ">";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "<div class=\"col-lg-5 col-xl-4\">";
                display += "<div class=\"s_product_text\">";
                display += "<h5>previous<span>|</span> next</h5>";
                display += "<h3>" + getPROD.PROD_NAME + "</h3>";
                display += "<h2>" + getPROD.PROD_PRICE + "</h2>";
                display += "<ul class=\"list\">";
                display += "<li>";
                display += "<a class=\"active\" href=\"#\">";
                display += "<span>Category</span> : Household</a>";
                display += "</li>";
                display += "<li>";
                display += "<a href=\"#\"><span>Availibility</span> : In Stock</a>";
                display += "</li>";
                display += "</ul>";
                display += "<p>";
                display += "First replenish living.Creepeth image image.Creeping can't, won't called. Two fruitful let days signs sea together all land fly subdue";
                display += "</p>";
                display += "<div class=\"card_area d-flex justify-content-between align-items-center\">";
                display += "<div class=\"product_count\">";
                display += "<span class=\"inumber-decrement\"><i class=\"ti-minus\"></i></span>";
                display += "<input class=\"input-number\" type=\"text\" value=\"1\" min=\"0\" max=\"10\">";
                display += "<span class=\"number-increment\"><i class=\"ti-plus\"></i></span>";
                display += "</div>";
                display += "<a href='cart.aspx?crtItemID="+getPROD.Id+"' class=\"btn_3\">add to cart</a>";
                display += "<a href=\"#\" class=\"like_us\"><i class=\"ti-heart\"></i></a>";
                display += "</div>";
                display += "</div>";
                display += "</div>";

                displaysingleProd.InnerHtml = display;
            }

            if(getReviewList != null)
            {
                String display2 = "";
                foreach(ProductReview pr in getReviewList)
                {
                    if(pr != null)
                    {
                        display2 += "  <div class=\"d-flex\">";
                        display2 += "    <img src="+pr.prodIMAGE+ " alt=\"\" width=\"100\" height=\"100\" />";
                        display2 += "  </div>";
                        display2 += "  <div class=\"media-body\">";
                        display2 += "    <h4>"+pr.userNAME+"</h4>";
                        display2 += "    <i class=\"fa fa-star\"></i>";
                        display2 += "    <i class=\"fa fa-star\"></i>";
                        display2 += "    <i class=\"fa fa-star\"></i>";
                        display2 += "    <i class=\"fa fa-star\"></i>";
                        display2 += "    <i class=\"fa fa-star\"></i>";
                        display2 += "  </div>";
                        display2 += "</div>";
                        display2 += "<p>"+pr.prodDescrption+"</p>";
                    }
                    else
                    {
                        display2 += "No Review for the product";
                    }
                }
                lblreviewss.InnerHtml = display2;
            }
            else
            {
                lblreviewComments.InnerHtml = "No Review for the product";
            }
        }
    }
}