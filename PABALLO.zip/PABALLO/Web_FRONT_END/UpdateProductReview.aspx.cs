﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class UpdateProductReview : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpdateReview_Click(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                if(Request.QueryString["updateIDreview"] != null)
                {
                    int id = int.Parse(Request.QueryString["updateIDreview"].ToString());
                    var updatereview = sr.editProdReview(id, updatedesc.Value);
                    if(updatereview)
                    {
                        Response.Redirect("productReview.aspx");
                    }
                }
            }
        }
    }
}