﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class invoice : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Customer"] != null)
            {
                generateInvoiceItems();
            }
        }

        private void generateInvoiceItems()
        {
            int userID = int.Parse(Session["Customer"].ToString());
            var getProdCart = sr.getAddedItems(userID);

            StringBuilder display = new StringBuilder();

            if (getProdCart != null)
            {
                // Add CSS class to style the table
                itemm.CssClass = "invoice-table";

                TableRow headerRow = new TableRow();

                // Correct the column header texts
                TableCell nameHeader = new TableCell();
                nameHeader.Text = "Description";
                headerRow.Cells.Add(nameHeader);

                TableCell quantityHeader = new TableCell();
                quantityHeader.Text = "Quantity";
                headerRow.Cells.Add(quantityHeader);

                TableCell unitPriceHeader = new TableCell();
                unitPriceHeader.Text = "Unit Price";
                headerRow.Cells.Add(unitPriceHeader);

                TableCell totalPriceHeader = new TableCell();
                totalPriceHeader.Text = "Total";
                headerRow.Cells.Add(totalPriceHeader);

                itemm.Rows.Add(headerRow);

                foreach (ShoppingCart s in getProdCart)
                {
                    TableRow row = new TableRow();

                    // Correct the row cell assignments
                    TableCell namecell = new TableCell();
                    namecell.Text = s.PROD_NAME;
                    row.Cells.Add(namecell);
                 
                    TableCell quantitycell = new TableCell();
                    quantitycell.Text = s.PROD_QUANTITY.ToString();
                    row.Cells.Add(quantitycell);

                    TableCell unitPricecell = new TableCell();
                    unitPricecell.Text = s.PROD_PRICE.ToString();
                    row.Cells.Add(unitPricecell);

                    TableCell totalcell = new TableCell();
                    totalcell.Text = s.TOTAL_PRICE.ToString();
                    row.Cells.Add(totalcell);

                    itemm.Rows.Add(row);

                    var addtoPreview = sr.addToProdReview(userID , Session["USERNAME"].ToString() , " ",s.PROD_ID , (double)s.PROD_PRICE , s.PROD_IMAGE , s.PROD_NAME , " ");
                }

                // Correct the assignment of inner HTML elements
                clientNAME.InnerHtml = "Client Name: " + Session["USERNAME"];
                clientADDRESS.InnerHtml = "Client Address: " + Session["USERADDRESS"];
                clientCITY.InnerHtml = "Client City: " + Session["CLIENT_CITY"];
                clientEMAIL.InnerHtml = "Client Email: " + Session["CLIENT_email"];
                INV_ID.InnerHtml = "INV - 0" + Session["INVOICE_ID"];
                INV_DATE.InnerHtml = Session["InvoiceDATE"].ToString();
                totalprice.InnerHtml = "Total Price: " + Session["TOTAL_PRICE"];
            }
        }
    }
}