﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class register : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            var userexist = sr.userExistence(useremail.Value);
            if(userexist)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('User already exists , Login')", true);
            }
            else
            {
                if(!(confirmpassword.Value.Equals(password.Value)))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Password do not match')", true);
                }
                else
                {
                    var register = sr.Register(username.Value, usersurname.Value, useremail.Value,usercontact.Value,"customer",password.Value);
                    if(register != null)
                    {
                        Session["Customer"] = register.Id;
                        Session["customername"] = register.USERNAME;
                        Session["TYPE"] = register.USERTYPE;
                        Response.Redirect("category.aspx");
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('User couldn't register')", true);
                    }
                }
            }
        }
    }
}