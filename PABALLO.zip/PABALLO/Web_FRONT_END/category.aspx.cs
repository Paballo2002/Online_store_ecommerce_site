﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class category : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Customer"] != null)
            {
                lblusername.InnerHtml = "Welcome " + Session["customername"].ToString()+"! Shop with us" ;
                
            }
            DisplayAllProd();
        }

        private String generateProd(Product prod)
        {
            if(prod != null)
            {
                string display = "";

                display += "<div class=\"col-lg-4 col-sm-6\">";
                display += "<div class=\"single_product_item\">";
                display += "<img src=" + prod.PROD_IMAGE + " alt=\"\" width=\"300\" height=\"300\">";
                display += "<div class=\"single_product_text\">";
                display += "<a href='singleproduct.aspx?prodid=" + prod.Id + "'><h4>" + prod.PROD_NAME + "</h4></a>";
                display += "<h3>R" + prod.PROD_PRICE + "</h3>";
                display += "<a href='' class=\"add_cart\">+ add to cart</a>";
                display += "<a href='wishList.aspx?addtowishLISTID=" + prod.Id + "' class=\"add_to_favorites\"><i class=\"ti-heart\"></i></a>";
                display += "</div>";
                display += "</div>";
                display += "</div>";

                return display;
            }
            else
            {
                lblDisplayProductCategory.InnerHtml = "Products out of stock";
                return null;
            }
        }

        private void DisplayAllProd()
        {
            var getAllProd = sr.prod_List();
            string display = "";
            if (getAllProd != null)
            {
                foreach(Product prod in getAllProd)
                {
                    display += generateProd(prod);
                }
                lblDisplayProductCategory.InnerHtml = display;
            }
            else
            {
                lblDisplayProductCategory.InnerHtml = "Couldn't display products";
            }
        }

        protected void filterBycategory_Click(object sender, EventArgs e)
        {
            LinkButton lnkbutton = (LinkButton)sender;
            string type_id = lnkbutton.ID;
            if(type_id.Equals("SHOES") || type_id.Equals("BAG") || type_id.Equals("CHAIR") || type_id.Equals("WATCH"))
            {
                var getProdBYTYPE = sr.getProdByType(type_id);
                if(getProdBYTYPE != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdBYTYPE)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if(type_id.Equals("lbl1000"))
            {
                var getProdByPrice = sr.getProdByPrice(0,1000);
                if(getProdByPrice != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdByPrice)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2000"))
            {
                var getProdByPrice = sr.getProdByPrice(1000, 2000);
                if(getProdByPrice != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdByPrice)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl3000"))
            {
                var getProdByPrice = sr.getProdByPrice(2000, 3000);
                if(getProdByPrice != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdByPrice)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl4000"))
            {
                var getProdByPrice = sr.getProdByPrice(3000, 4000);
                if(getProdByPrice != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdByPrice)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("BLACK") || type_id.Equals("RED") || type_id.Equals("GREEN") || type_id.Equals("ORANGE") || type_id.Equals("PINK") || type_id.Equals("YELLOW"))
            {
                var getProdByColour = sr.getProdByColour(type_id);
                if(getProdByColour != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdByColour)
                    {

                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2015"))
            {
                var getProdDate = sr.getProdByYear(2015);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2016"))
            {
                var getProdDate = sr.getProdByYear(2016);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2017"))
            {
                var getProdDate = sr.getProdByYear(2017);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2019"))
            {
                var getProdDate = sr.getProdByYear(2019);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2020"))
            {
                var getProdDate = sr.getProdByYear(2020);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2021"))
            {
                var getProdDate = sr.getProdByYear(2021);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else if (type_id.Equals("lbl2023"))
            {
                var getProdDate = sr.getProdByYear(2023);
                if(getProdDate != null)
                {
                    string display = "";
                    foreach (Product PROD in getProdDate)
                    {
                        display += generateProd(PROD);
                    }
                    lblDisplayProductCategory.InnerHtml = display;
                }
                else
                {
                    lblDisplayProductCategory.InnerHtml = "Products out of stock";
                }
            }
            else
            {
                lblDisplayProductCategory.InnerHtml = "Products out of stock";
            }
        }
    }
}