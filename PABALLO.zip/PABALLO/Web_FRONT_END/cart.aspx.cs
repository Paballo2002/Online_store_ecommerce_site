﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class cart : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Customer"] != null)
            {
                if (Request.QueryString["crtItemID"] != null)
                {
                    int itemID = int.Parse(Request.QueryString["crtItemID"]);
                    int userID = int.Parse(Session["Customer"].ToString());

                    var getPRODUCT = sr.getProd(itemID);
                    if (getPRODUCT != null)
                    {
                        var addToCart = sr.addToCart(getPRODUCT.Id, userID, getPRODUCT.PROD_NAME, (double)getPRODUCT.PROD_PRICE , getPRODUCT.PROD_IMAGE, getPRODUCT.PROD_TYPE , 1 ,(double)getPRODUCT.PROD_PRICE , (double)getPRODUCT.PROD_DISCOUNT);
                        if (addToCart != null)
                        {
                            displayItems();
                        }
                    }
                }
                else
                {
                    displayItems();
                }
            }
            else
            {
                tableDisplay.InnerHtml = "Login or Register first to add to cart";
            }
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (Request.QueryString["removeITEMID"] != null)
            {
                int itemToRemove = int.Parse(Request.QueryString["removeITEMID"]);
                var getRemoveItem = sr.removeFromCart(itemToRemove);
                if (getRemoveItem)
                {
                    displayItems();
                }
                else
                {
                    displayItems();
                }
            }
            else if(Request.QueryString["decrementID"] != null)
            {
                int itemToDec = int.Parse(Request.QueryString["decrementID"]);
                var decre = sr.decreaseQuantity(itemToDec);
                if (decre)
                {
                    displayItems();
                }
                else
                {
                    displayItems();
                }
            }
            else if(Request.QueryString["incrementID"] != null)
            {
                int itemToInc = int.Parse(Request.QueryString["incrementID"]);
                var Incre = sr.increaseQuantity(itemToInc);
                if (Incre)
                {
                    displayItems();
                }
                else
                {
                    displayItems();
                }
            }
        }

        private void displayItems()
        {
            if(Session["Customer"] != null)
            {
                var display = "";
                int userID = int.Parse(Session["Customer"].ToString());
                var getProdCart = sr.getAddedItems(userID);

                double subTOTAL = sr.totalPRICE(userID);
                decimal vat = (decimal)((0.15) * (subTOTAL));

                double ALLTOTAL = (subTOTAL + (double)vat);

                if (getProdCart != null)
                {
             
                    foreach (ShoppingCart w in getProdCart)
                    {
                        if(w != null)
                        {
                            display += "<tr>";
                            display += "  <td>";
                            display += "    <div class=\"media\">";
                            display += "      <div class=\"d-flex\">";
                            display += "<img src=" + w.PROD_IMAGE + " alt=\"\" width=\"100\" height=\"100\"/>";
                            display += "      </div>";
                            display += "      <div class=\"media-body\">";
                            display += "        <p>" + w.PROD_NAME + "</p>";
                            display += "      </div>";
                            display += "    </div>";
                            display += "  </td>";
                            display += "  <td>";
                            display += "    <h5>R" + w.PROD_PRICE + "</h5>";
                            display += "  </td>";
                            display += "  <td>";
                            display += "    <div class=\"product_count\">";
                            display += "    <a href='?decrementID=" + w.Id + "'><span class=\"input-number-decrement\"><i class=\"ti-angle-down\"></i></span></a>";
                            display += "      <input class=\"input-number\" type=\"text\" value=" + (w.PROD_QUANTITY) + ">";
                            display += "     <a href='?incrementID=" + w.Id + "'><span class=\"input-number-increment\"><i class=\"ti-angle-up\"></i></span></a>";
                            display += "    </div>";
                            display += "  </td>";
                            display += "  <td>";
                            display += "    <h5>R" + (w.TOTAL_PRICE) + "</h5>";
                            display += "  </td>";
                            display += "  <td>";
                            display += "    <a href='?removeITEMID=" + w.Id + "'>- Remove</a>";
                            display += "  </td>";
                            display += "</tr>";
                        }
                        else
                        {
                            display += "Add Items To cart";
                        }
                    }
                    display += "<tr>";
                    display += "  <td></td>";
                    display += "  <td class=\"auto-style1\"></td>";
                    display += "  <td>";
                    display += "    <h5>Subtotal</h5>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <h5>R" + ALLTOTAL + "</h5>";
                    display += "  </td>";
                    display += "</tr>";
                    display += "<tr class=\"shipping_area\">";
                    display += "  <td></td>";
                    display += "  <td class=\"auto-style1\"></td>";
                    display += "  <td>";
                    display += "    <div class=\"shipping_box\">";
                    //display += "      <ul class=\"list\">";
                    //display += "        <li>";
                    //display += "          <a href=\"#\">Flat Rate: $5.00</a>";
                    //display += "        </li>";
                    //display += "        <li>";
                    //display += "          <a href=\"#\">Free Shipping</a>";
                    //display += "        </li>";
                    //display += "        <li>";
                    //display += "          <a href=\"#\">Flat Rate: $10.00</a>";
                    //display += "        </li>";
                    //display += "        <li class=\"active\">";
                    //display += "          <a href=\"#\">Local Delivery: $2.00</a>";
                    //display += "        </li>";
                    //display += "      </ul>";
                    //display += "      <h6>";
                    //display += "        Calculate Shipping";
                    //display += "        <i class=\"fa fa-caret-down\" aria-hidden=\"true\"></i>";
                    //display += "      </h6>";
                    //display += "      <select class=\"shipping_select\">";
                    //display += "        <option value=\"1\">Bangladesh</option>";
                    //display += "        <option value=\"2\">India</option>";
                    //display += "        <option value=\"4\">Pakistan</option>";
                    //display += "      </select>";
                    //display += "      <select class=\"shipping_select section_bg\">";
                    //display += "        <option value=\"1\">Select a State</option>";
                    //display += "        <option value=\"2\">Select a State</option>";
                    //display += "        <option value=\"4\">Select a State</option>";
                    //display += "      </select>";
                    //display += "      <input type=\"text\" placeholder=\"Postcode/Zipcode\" />";
                    //display += "      <a class=\"btn_1\" href=\"#\">Update Details</a>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "</tr>";

                    Session["SUBTotal"] = subTOTAL;
                    Session["TOTAL_PRICE"] = ALLTOTAL;
                    Session["VAT"] = vat;

                    tableDisplay.InnerHtml = display;
                }
                else
                {
                    tableDisplay.InnerHtml = "Add Items to a cart";
                }
            }
        }
    }
}