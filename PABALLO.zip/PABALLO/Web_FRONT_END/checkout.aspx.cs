﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class checkout : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Customer"] != null)
            {
                generateProducts();
            }
        }

        private void generateProducts()
        {
            int userID = int.Parse(Session["Customer"].ToString());
            var getProdCart = sr.getAddedItems(userID);
            string display = "";
            if(getProdCart != null)
            {
                display = "<li>"; 
                display = "<a href=\"#\">Product";  
                display = "<span>Total</span>";     
                display = "</a>";   
                display = "</li>";  
                foreach (ShoppingCart s in getProdCart)
                {
                    display = "<li>";
                    display = "<a href=\"#\">"+s.PROD_NAME+"";
                    display = "<span class=\"middle\">x "+s.PROD_QUANTITY+"</span>";       
                    display = "<span class=\"last\">"+s.PROD_PRICE+"</span>";
                    display = "</a>"; 
                    display = "</li>";
                }
                subtotal.InnerHtml = "R"+Session["SUBTotal"].ToString();
                total.InnerHtml = "R" + Session["TOTAL_PRICE"].ToString() + 150;

                displayProducts.InnerHtml = display;
            }
            else
            {
                displayProducts.InnerHtml = "Add Items to a cart";
            }
        }

        protected void btnInvoice_Click(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                int userID = int.Parse(Session["Customer"].ToString());
                double VAT = double.Parse(Session["VAT"].ToString());
                double totalPrice = (double)Session["TOTAL_PRICE"];
                String username = Session["customername"].ToString();
                DateTime date = DateTime.Now;

                var addToInvoice = sr.generateInvoice(totalPrice , firstname.Value , lastname.Value  , number.Value , email.Value , add1.Value + add2.Value, city.Value , date , 100 , userID , VAT);
                if(addToInvoice != null)
                {
                    Session["INVOICE_ID"] = addToInvoice.Id;
                    Session["TotalPRICE"] = addToInvoice.PROD_TOTAL;
                    Session["USERNAME"] = addToInvoice.USER_NAME;
                    Session["DATE"] = addToInvoice.DATE;
                    Session["DISCOUNT"] = addToInvoice.TOTAL_DISC;
                    Session["TAX"] = addToInvoice.VAT;
                    Session["USERADDRESS"] = addToInvoice.USER_ADRESS;
                    Session["CLIENT_CITY"] = addToInvoice.USER_city;
                    Session["CLIENT_email"] = addToInvoice.USER_EMAIL;
                    Session["InvoiceDATE"] = addToInvoice.DATE;

                    Response.Redirect("invoice.aspx");
                }
            }
        }
    }
}