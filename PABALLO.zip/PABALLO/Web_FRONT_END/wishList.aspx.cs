﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class wishlist : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Request.QueryString["addtowishLISTID"] != null)
            {
                int id = int.Parse(Request.QueryString["addtowishLISTID"]);
                var getPRODUCT = sr.getProd(id);
                if(getPRODUCT != null)
                {
                    var addToWishList = sr.addToWishList(getPRODUCT.Id , getPRODUCT.PROD_IMAGE , getPRODUCT.PROD_NAME , (double)getPRODUCT.PROD_PRICE , 0);
                    if(addToWishList != null)
                    {
                        displayItems();
                    }
                }
            } 
            else
            {
                displayItems();
            }
        }

        protected void Page_LoadComplete(object sender , EventArgs e)
        {
            if (Request.QueryString["removeITem"] != null)
            {
                int itemToRemove = int.Parse(Request.QueryString["removeITem"]);
                var getRemoveItem = sr.removeFromWishlist(itemToRemove);
                if (getRemoveItem)
                {
                    displayItems();
                }
                else
                {
                    displayItems();
                }
            }
        }

        private void displayItems()
        {
            var display = "";

            var getAllWishListProd = sr.GetWishListItems();

            if(getAllWishListProd != null)
            {
                foreach (WishList w in getAllWishListProd)
                {
                    display += "<tr>";
                    display += "  <td>";
                    display += "    <div class=\"media\">";
                    display += "      <div class=\"d-flex\">";
                    display += "<img src=" + w.PROD_IMAGE + " alt=\"\" width=\"100\" height=\"100\"/>";
                    display += "      </div>";
                    display += "      <div class=\"media-body\">";
                    display += "        <p>"+w.PROD_NAME+"</p>";
                    display += "      </div>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <h5>R"+w.PROD_PRICE+"</h5>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "    <div class=\"product_count\">";
                    display += "<a href='?removeITem="+w.PROD_ID+"' class=\"add_cart\"> - Remove</a>";
                    display += "    </div>";
                    display += "  </td>";
                    display += "  <td>";
                    display += "<a href='cart.aspx?crtItemID=" + w.PROD_ID+"' class=\"add_cart\">+ Add to cart</a>";
                    display += "  </td>";
                    display += "</tr>";
                }
                tabledisplay.InnerHtml = display;
            }
        }
    }
}