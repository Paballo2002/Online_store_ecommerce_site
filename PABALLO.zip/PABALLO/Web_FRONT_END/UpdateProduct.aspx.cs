﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web_FRONT_END.ServiceReference1;

namespace Web_FRONT_END
{
    public partial class UpdateProduct : System.Web.UI.Page
    {
        Iservice_applicationClient sr = new Iservice_applicationClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            HttpPostedFile uploadedFile = prodImage.PostedFile;
            string fileName = Path.GetFileName(uploadedFile.FileName);

            if (Request.QueryString["updateID"] != null)
            {
                int prodID = int.Parse(Request.QueryString["updateID"]);
                var update = sr.editProduct(prodID, prodname.Value, prodColour.Value,double.Parse(prodPrice.Value), " img/product/" + fileName, prodType.Value, double.Parse(prodDisc.Value), DateTime.Parse(prodDate.Value));
                if(update)
                {
                    Response.Redirect("managerpage.aspx");
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could not Update product')", true);
                }
            }
        }
    }
}